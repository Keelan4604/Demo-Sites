<?php
/**
 * Template Name: EcoPro Custom Homepage
 * Description: Custom landing page template for EcoPro USA.
 */

if (! defined('ABSPATH')) {
    exit;
}

get_header();
?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Playfair+Display:wght@700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo esc_url(get_stylesheet_directory_uri() . '/ecopro-custom/style.css'); ?>">

<header class="site-header" id="site-header">
  <div class="container header-inner">
    <a href="<?php echo esc_url(home_url('/')); ?>" class="logo" aria-label="EcoPro USA Home">
      <img src="<?php echo esc_url(get_stylesheet_directory_uri() . '/ecopro-custom/images/eco-pro-logo-300x73.png'); ?>" alt="EcoPro USA" width="180" height="44">
    </a>
    <nav class="main-nav" id="main-nav" aria-label="Main navigation">
      <ul class="nav-list">
        <li><a href="#hero" class="nav-link active">Home</a></li>
        <li><a href="#about" class="nav-link">About</a></li>
        <li><a href="#products" class="nav-link">Products</a></li>
        <li><a href="#results" class="nav-link">Results</a></li>
        <li><a href="#contact" class="nav-link">Contact</a></li>
      </ul>
    </nav>
    <div class="header-actions">
      <a href="#contact" class="btn btn-primary btn-sm">Get a Quote</a>
      <button class="mobile-toggle" id="mobile-toggle" aria-label="Toggle menu" aria-expanded="false">
        <span class="hamburger"></span>
      </button>
    </div>
  </div>
</header>

<section class="hero" id="hero">
  <div class="hero-bg">
    <div class="hero-slide active" style="background-image:url('https://ecoprousa.com/wp-content/uploads/2022/06/slide-1-bg.jpg')"></div>
    <div class="hero-slide" style="background-image:url('https://ecoprousa.com/wp-content/uploads/2022/06/slidd-2-bg.jpg')"></div>
    <div class="hero-slide" style="background-image:url('https://ecoprousa.com/wp-content/uploads/2022/06/slide-3-bg.jpg')"></div>
  </div>
  <div class="hero-overlay"></div>
  <div class="container hero-content">
    <div class="hero-text">
      <p class="hero-eyebrow reveal">Trusted by Fleets Nationwide</p>
      <h1 class="hero-headline reveal">Cleaner Air.<br>Longer Life.<br><span class="text-accent">Proven Performance.</span></h1>
      <p class="hero-sub reveal">Industrial-grade filtration, lighting, and protection products that reduce costs, extend equipment life, and keep operators safe — without voiding a single warranty.</p>
      <div class="hero-ctas reveal">
        <a href="#products" class="btn btn-primary btn-lg">Explore Products</a>
        <a href="#contact" class="btn btn-outline btn-lg">Contact EcoPro</a>
      </div>
    </div>
    <div class="hero-stats reveal">
      <div class="stat-chip">
        <span class="stat-number" data-target="12000" data-prefix="$">$0</span>
        <span class="stat-label">Avg. Annual Savings</span>
      </div>
      <div class="stat-chip">
        <span class="stat-number" data-target="25000">0</span>
        <span class="stat-label">Hours Proven</span>
      </div>
      <div class="stat-chip">
        <span class="stat-number" data-target="40" data-suffix="+">0</span>
        <span class="stat-label">Years on the Market</span>
      </div>
    </div>
  </div>
  <div class="hero-scroll-hint" aria-hidden="true"><span></span></div>
</section>

<section class="section what-we-do" id="about">
  <div class="container">
    <div class="section-header reveal">
      <p class="section-eyebrow">What We Do</p>
      <h2 class="section-title">Built for the People<br>Who Run the Equipment</h2>
      <p class="section-sub">We're not a manufacturer's rep. We're an independent solutions company that works exclusively for the end user — selecting only the best, safest, and most proven products on the market.</p>
    </div>
    <div class="pillars-grid">
      <div class="pillar-card reveal">
        <div class="pillar-icon"><svg width="48" height="48" viewBox="0 0 48 48" fill="none" aria-hidden="true"><circle cx="24" cy="24" r="22" stroke="currentColor" stroke-width="2"/><path d="M16 24l6 6 10-12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
        <h3 class="pillar-title">We Work for You — Not the Manufacturer</h3>
        <p class="pillar-text">This is integral to who we are. We promote only the products we believe in — chosen for real-world performance, not brand loyalty. Your uptime and bottom line come first.</p>
      </div>
      <div class="pillar-card reveal">
        <div class="pillar-icon"><svg width="48" height="48" viewBox="0 0 48 48" fill="none" aria-hidden="true"><path d="M24 4l5.18 10.5L40 16.27l-8 7.8 1.89 11.01L24 30.24l-9.89 4.84L16 24.07l-8-7.8 10.82-1.77z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg></div>
        <h3 class="pillar-title">Nothing We Sell Will Void Warranties</h3>
        <p class="pillar-text">Every product we carry is designed to integrate safely with your existing equipment. They reduce costs, improve efficiency, extend asset longevity, and support your sustainability initiatives.</p>
      </div>
      <div class="pillar-card reveal">
        <div class="pillar-icon"><svg width="48" height="48" viewBox="0 0 48 48" fill="none" aria-hidden="true"><path d="M24 4C13 4 4 13 4 24s9 20 20 20 20-9 20-20S35 4 24 4z" stroke="currentColor" stroke-width="2"/><path d="M16 28c0-4.4 3.6-8 8-8s8 3.6 8 8" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="24" cy="16" r="3" stroke="currentColor" stroke-width="2"/></svg></div>
        <h3 class="pillar-title">Real Environmental Impact</h3>
        <p class="pillar-text">Beyond cost savings, our products deliver reduced emissions, less waste, and extended asset life. Doing right by the environment and your fleet aren't mutually exclusive.</p>
      </div>
    </div>
  </div>
</section>

<section class="section why-ecopro">
  <div class="why-ecopro-bg" style="background-image:url('https://ecoprousa.com/wp-content/uploads/2022/06/our-products.jpg')"></div>
  <div class="why-ecopro-overlay"></div>
  <div class="container why-ecopro-inner">
    <div class="why-text reveal">
      <p class="section-eyebrow light">Why EcoPro</p>
      <h2 class="section-title light">100% Tested.<br>100% Validated.<br>100% Proven.</h2>
      <p class="why-description">Every product in our lineup has been rigorously tested and validated in the harshest real-world conditions. We stand behind what we sell — with start-to-finish support, from selection through installation.</p>
      <a href="#products" class="btn btn-primary btn-lg">See Our Products</a>
    </div>
    <div class="why-badges reveal">
      <ul class="badge-list">
        <li class="badge-item"><span class="badge-icon">&#10003;</span> Safe &amp; Proven Technology</li>
        <li class="badge-item"><span class="badge-icon">&#10003;</span> Will Not Void Warranty</li>
        <li class="badge-item"><span class="badge-icon">&#10003;</span> Verified Products</li>
        <li class="badge-item"><span class="badge-icon">&#10003;</span> High Return on Investment</li>
        <li class="badge-item"><span class="badge-icon">&#10003;</span> Sizes for All Equipment</li>
        <li class="badge-item"><span class="badge-icon">&#10003;</span> Strong Customer Service</li>
        <li class="badge-item"><span class="badge-icon">&#10003;</span> Installation Available</li>
        <li class="badge-item"><span class="badge-icon">&#10003;</span> Made in the USA</li>
        <li class="badge-item"><span class="badge-icon">&#10003;</span> Independently Owned &amp; Operated</li>
        <li class="badge-item"><span class="badge-icon">&#10003;</span> Not a Manufacturer's Rep</li>
        <li class="badge-item"><span class="badge-icon">&#10003;</span> Positive Environmental Impact</li>
      </ul>
    </div>
  </div>
</section>

<section class="section products" id="products">
  <div class="container">
    <div class="section-header reveal">
      <p class="section-eyebrow">Featured Products</p>
      <h2 class="section-title">Engineered for the<br>Toughest Environments</h2>
      <p class="section-sub">From pre-cleaners that extend filter life 3–5x to cabin pressurizers delivering air 200x cleaner than competitors — these are products that earn their keep.</p>
    </div>
    <div class="products-grid">
      <div class="product-card reveal"><div class="product-img"><img src="https://ecoprousa.com/wp-content/uploads/2022/06/product-1.png" alt="Turbo II HD PreCleaner" loading="lazy"></div><div class="product-body"><h3 class="product-name">Turbo II HD PreCleaner</h3><p class="product-desc">Centrifugal pre-cleaner with 40+ years of proven performance. Extends engine air filter life 3–5x in the harshest dust environments. One moving part. Lifetime-warranted spinner.</p><ul class="product-highlights"><li>80–90% improved filtration</li><li>SAE J726 independently tested</li><li>Fits loaders, graders, haulers &amp; more</li></ul><a href="#contact" class="btn btn-secondary">Learn More</a></div></div>
      <div class="product-card reveal"><div class="product-img"><img src="https://ecoprousa.com/wp-content/uploads/2022/06/product-2.png" alt="Clean Cabin Air Pressurizer" loading="lazy"></div><div class="product-body"><h3 class="product-name">Cabin Air Pressurizer</h3><p class="product-desc">Three-stage filtration system that pressurizes equipment cabs to deliver air 200x cleaner than leading competitors at 0.3 microns. German-engineered motor in a powder-coated steel enclosure.</p><ul class="product-highlights"><li>99.998% efficient at 0.3 microns</li><li>2,000-hour filter life</li><li>Equipment-specific kits available</li></ul><a href="#contact" class="btn btn-secondary">Learn More</a></div></div>
      <div class="product-card reveal"><div class="product-img"><img src="https://ecoprousa.com/wp-content/uploads/2025/04/DuraLux-Gen-2_9-LED-Large-300x232.png" alt="LED HD Work Lights" loading="lazy"></div><div class="product-body"><h3 class="product-name">LED HD Lights</h3><p class="product-desc">Mining-grade H30 Series LED work lights built to withstand extreme vibration, washdowns, and harsh operating environments. Plug-and-play DT connectors with sealed construction.</p><ul class="product-highlights"><li>Mining-grade durability</li><li>Extreme vibration rated</li><li>Plug-and-play installation</li></ul><a href="#contact" class="btn btn-secondary">Learn More</a></div></div>
      <div class="product-card reveal"><div class="product-img"><img src="https://ecoprousa.com/wp-content/uploads/2022/06/product-4.png" alt="Desiccant Breathers" loading="lazy"></div><div class="product-body"><h3 class="product-name">Desiccant Breathers</h3><p class="product-desc">Protect diesel and lubricant storage from moisture and airborne contaminants. Color-changing silica indicates replacement timing. Prevents rust, sludge, and microbial growth.</p><ul class="product-highlights"><li>Visual replacement indicator</li><li>Diesel &amp; lubricant protection</li><li>Low-profile options available</li></ul><a href="#contact" class="btn btn-secondary">Learn More</a></div></div>
      <div class="product-card reveal"><div class="product-img"><img src="https://ecoprousa.com/wp-content/uploads/2023/06/My-project-1-4-2-300x263.jpg" alt="Metal Adapters" loading="lazy"></div><div class="product-body"><h3 class="product-name">Metal Adapters</h3><p class="product-desc">In-house manufactured metal stack extensions, expansion adapters, and custom brackets. Precision metal spinning, bracket design, and HVAC access panels for any application.</p><ul class="product-highlights"><li>Custom in-house manufacturing</li><li>Stack extensions &amp; expansion adapters</li><li>90-day warranty</li></ul><a href="#contact" class="btn btn-secondary">Learn More</a></div></div>
    </div>
  </div>
</section>

<section class="section results" id="results">
  <div class="container">
    <div class="section-header reveal">
      <p class="section-eyebrow">Proven Results</p>
      <h2 class="section-title">Real Outcomes from<br>Real Operations</h2>
      <p class="section-sub">Don't take our word for it. Here's what happens when EcoPro products go to work.</p>
    </div>
    <div class="results-grid">
      <div class="result-card result-case reveal"><div class="result-tag">Case Study — Turbo II HD</div><h3 class="result-headline">$12,000/Year Saved in Engine Air Filters</h3><p class="result-detail">A recycling facility in Michigan went from 12 engine air filters per month to just 2 — saving $12,000 annually — after installing Turbo II HD PreCleaners.</p><span class="result-source">Recycling Facility, Michigan</span></div>
      <div class="result-card result-case reveal"><div class="result-tag">Case Study — CCAP</div><h3 class="result-headline">25,000 Hours on a D6T Dozer</h3><p class="result-detail">A cabin air pressurizer on a D6T dozer at a Massachusetts municipality landfill reached 25,000 hours of operation — proving long-term reliability in demanding conditions.</p><span class="result-source">Massachusetts Municipality Landfill</span></div>
      <div class="result-card result-case reveal"><div class="result-tag">Case Study — CCAP</div><h3 class="result-headline">Clean HVAC After 3 Years</h3><p class="result-detail">After 3 years of continuous use at an Arizona landfill, the HVAC system remained clean — demonstrating the pressurizer's ability to keep contaminants out of the cab.</p><span class="result-source">Arizona Landfill</span></div>
    </div>
    <div class="testimonials-slider reveal" id="testimonials-slider">
      <div class="testimonials-track">
        <div class="testimonial-card"><blockquote class="testimonial-quote">"If you are looking for awesome, knowledgeable people to work with, these are the guys I highly recommend."</blockquote><div class="testimonial-author"><strong>Charlie S., CEO</strong><span>Hunter Contracting</span></div></div>
        <div class="testimonial-card"><blockquote class="testimonial-quote">"Thank you so much for your help and time. You have amazing customer service."</blockquote><div class="testimonial-author"><strong>Fleet Manager</strong><span>Tennessee Waste Industry</span></div></div>
        <div class="testimonial-card"><blockquote class="testimonial-quote">"Man they were bright and very simple. Just plug and go — believe I have another machine that we will be installing these on here soon!"</blockquote><div class="testimonial-author"><strong>Aaron Z.</strong><span>Field Operations</span></div></div>
        <div class="testimonial-card"><blockquote class="testimonial-quote">"Operators clearly notice cleaner cabin air. The difference is unmistakable — especially in dusty landfill conditions."</blockquote><div class="testimonial-author"><strong>Operations Manager</strong><span>Indiana Landfill</span></div></div>
      </div>
      <div class="slider-controls"><button class="slider-btn slider-prev" aria-label="Previous testimonial">&#8592;</button><div class="slider-dots" id="slider-dots"></div><button class="slider-btn slider-next" aria-label="Next testimonial">&#8594;</button></div>
    </div>
  </div>
</section>

<section class="section trusted">
  <div class="container">
    <div class="section-header reveal">
      <p class="section-eyebrow">Trusted By</p>
      <h2 class="section-title">Proven Across Industries</h2>
    </div>
    <div class="logo-marquee reveal" aria-label="Customer logos">
      <div class="marquee-track">
        <div class="marquee-item">US Air Force</div>
        <div class="marquee-item">Argonaut Gold</div>
        <div class="marquee-item">Salt River Landfill</div>
        <div class="marquee-item">RDO Equipment Co</div>
        <div class="marquee-item">Hunter Contracting</div>
        <div class="marquee-item">Aggregate Industries</div>
        <div class="marquee-item">Arizona Materials</div>
        <div class="marquee-item">Sweeper Sales</div>
        <div class="marquee-item">US Air Force</div>
        <div class="marquee-item">Argonaut Gold</div>
        <div class="marquee-item">Salt River Landfill</div>
        <div class="marquee-item">RDO Equipment Co</div>
        <div class="marquee-item">Hunter Contracting</div>
        <div class="marquee-item">Aggregate Industries</div>
        <div class="marquee-item">Arizona Materials</div>
        <div class="marquee-item">Sweeper Sales</div>
      </div>
    </div>
  </div>
</section>

<section class="section cta-band" id="contact">
  <div class="container cta-inner">
    <div class="cta-text reveal">
      <h2 class="cta-headline">Ready to Protect Your Fleet?</h2>
      <p class="cta-sub">Talk to our team about the right products for your equipment. We'll help you select, size, and install — start to finish.</p>
    </div>
    <div class="cta-actions reveal">
      <a href="mailto:controller@ecoprousa.com" class="btn btn-primary btn-lg">Get a Quote</a>
      <a href="tel:8553267762" class="btn btn-outline-light btn-lg">Call 855-ECO-PRO2</a>
    </div>
  </div>
</section>

<script src="<?php echo esc_url(get_stylesheet_directory_uri() . '/ecopro-custom/script.js'); ?>"></script>

<?php get_footer(); ?>
